import React, { useState } from 'react';
import { 
  Users, 
  Send, 
  Globe, 
  HeartHandshake, 
  Trash2, 
  MessageSquare, 
  Search, 
  Sparkles,
  Smile
} from 'lucide-react';

const INITIAL_PUBLIC_PRAYERS = [
  {
    id: 'p-1',
    author: 'Maria de Souza (Ir.)',
    content: 'Oração pela saúde da minha filha Ana, que fará uma cirurgia na próxima semana de manhã. Que o Senhor guie as mãos dos médicos.',
    date: '18/06/2026',
    prayinCount: 14,
    userReacted: false,
    category: 'Saúde'
  },
  {
    id: 'p-2',
    author: 'Presbítero Carlos Santos',
    content: 'Pelo Mutirão Missionário do próximo sábado. Teremos entrega de folhetos e livros missionários nas proximidades do parque. Oremos para alcançar corações!',
    date: '18/06/2026',
    prayinCount: 9,
    userReacted: false,
    category: 'Trabalho Missionário'
  },
  {
    id: 'p-3',
    author: 'Marcos Rodrigues (Ir.)',
    content: 'Gratidão imensa a Deus por uma porta de emprego aberta após 6 meses de busca sincera! O Senhor é fiel!',
    date: '17/06/2026',
    prayinCount: 22,
    userReacted: true,
    category: 'Agradecimento'
  },
  {
    id: 'p-4',
    author: 'Amanda Lima (Jovem)',
    content: 'Peço oração pelas minhas decisões profissionais e vestibular. Que o Espírito Santo me guie no caminho reto.',
    date: '16/06/2026',
    prayinCount: 11,
    userReacted: false,
    category: 'Família/Vida Pessoal'
  }
];

export default function TabRelationship() {
  const [publicPrayers, setPublicPrayers] = useState<any[]>(() => {
    const saved = localStorage.getItem('discipulado_public_prayers');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_PUBLIC_PRAYERS;
      }
    }
    return INITIAL_PUBLIC_PRAYERS;
  });

  const [prayerAuthor, setPrayerAuthor] = useState('');
  const [prayerContent, setPrayerContent] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [prayerSuccess, setPrayerSuccess] = useState('');

  const handlePublishPrayer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prayerContent.trim()) return;

    const authorLabel = prayerAuthor.trim() ? prayerAuthor.trim() : 'Irmão(ã) Anônimo(a)';
    const newPrayer = {
      id: `p-custom-${Date.now()}`,
      author: authorLabel,
      content: prayerContent.trim(),
      date: new Date().toLocaleDateString('pt-BR'),
      prayinCount: 1,
      userReacted: true,
      isCustom: true
    };

    const updated = [newPrayer, ...publicPrayers];
    setPublicPrayers(updated);
    localStorage.setItem('discipulado_public_prayers', JSON.stringify(updated));

    setPrayerAuthor('');
    setPrayerContent('');
    setPrayerSuccess('✓ Seu pedido de oração foi publicado com sucesso no mural!');
    setTimeout(() => setPrayerSuccess(''), 4000);
  };

  const handlePrayReact = (id: string) => {
    const updated = publicPrayers.map((p) => {
      if (p.id === id) {
        const reacted = !p.userReacted;
        return {
          ...p,
          userReacted: reacted,
          prayinCount: reacted ? p.prayinCount + 1 : Math.max(0, p.prayinCount - 1)
        };
      }
      return p;
    });
    setPublicPrayers(updated);
    localStorage.setItem('discipulado_public_prayers', JSON.stringify(updated));
  };

  const handleRemoveOwn = (id: string) => {
    const updated = publicPrayers.filter(p => p.id !== id);
    setPublicPrayers(updated);
    localStorage.setItem('discipulado_public_prayers', JSON.stringify(updated));
  };

  const filteredPrayers = publicPrayers.filter((p) => {
    const matchesSearch = p.content.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.author.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  return (
    <div className="space-y-6 text-left animate-fade-in">
      
      {/* Header Banr */}
      <div className="bg-white border border-[#e5e0d5] rounded-3xl p-5 shadow-sm text-left relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-100/10 rounded-full blur-3xl" />
        <div className="relative space-y-2">
          <span className="text-[9px] font-black tracking-widest text-[#b48a30] uppercase bg-[#FDF8EB] px-2.5 py-1 rounded-md border border-[#f5ebcb] inline-block font-mono">
            Comunidade Ativa
          </span>
          <h3 id="relationship-title" className="text-xl font-black text-[#0f2646] leading-tight flex items-center gap-2">
            <HeartHandshake className="text-[#004b87] w-6 h-6 shrink-0" />
            Mural de Oração & Intercessão
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed font-sans pr-4">
            Aqui cultivamos a comunhão uns com os outros. Compartilhe pedidos de oração, acompanhe as necessidades dos irmãos e interceda em unidade de fé.
          </p>
        </div>
      </div>

      {/* Compartilhar Pedido Form */}
      <div className="bg-white border border-[#e5e0d5] rounded-3xl p-5 shadow-sm">
        <form onSubmit={handlePublishPrayer} className="space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-[#FAF9F5]">
            <div className="w-1.5 h-4 rounded-full bg-[#004b87]" />
            <h4 className="text-sm font-black text-[#0f2646] uppercase font-mono tracking-wider">Novo Pedido de Oração</h4>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 block">Seu Nome / Identificação:</label>
            <input
              id="inp-prayer-author"
              type="text"
              value={prayerAuthor}
              onChange={(e) => setPrayerAuthor(e.target.value)}
              placeholder="Ex: Ir. João, Irmã Cláudia, ou deixe em branco para Anônimo..."
              className="w-full bg-[#FAF9F5] border border-[#e5e0d5] focus:border-[#004b87] rounded-xl px-3.5 py-2 text-xs md:text-sm text-[#1e293b] placeholder:text-slate-400 font-sans outline-none font-medium"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-500 block">Detalhes do Pedido:</label>
            <textarea
              id="txt-prayer-content"
              value={prayerContent}
              onChange={(e) => setPrayerContent(e.target.value)}
              placeholder="Escreva aqui os detalhes da sua oração. Peça por saúde, decisões, proteção, família ou expresse um agradecimento sincero..."
              className="w-full h-24 bg-[#FAF9F5] border border-[#e5e0d5] focus:border-[#004b87] rounded-xl p-3.5 text-xs md:text-sm text-[#1e293b] placeholder:text-slate-400 font-sans outline-none resize-none shadow-inner"
              required
            />
          </div>

          {prayerSuccess && (
            <div className="text-xs text-emerald-700 font-mono text-center font-bold bg-emerald-50 px-3 py-2 rounded-xl border border-emerald-250">
              {prayerSuccess}
            </div>
          )}

          <button
            id="btn-publish-prayer"
            type="submit"
            disabled={!prayerContent.trim()}
            className="w-full bg-[#004b87] hover:bg-[#003b6d] disabled:opacity-40 disabled:pointer-events-none text-white font-bold py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 cursor-pointer text-xs shadow-sm transition-all"
          >
            <Send className="w-4 h-4 shrink-0" />
            Publicar no Mural da Igreja
          </button>
        </form>
      </div>

      {/* Mural List and Filters */}
      <div className="bg-white border border-[#e5e0d5] rounded-3xl p-5 shadow-sm space-y-4">
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#FAF9F5]">
          <h4 className="text-sm font-black text-[#0f2646] uppercase font-mono tracking-wider flex items-center gap-1.5">
            <Users className="w-4 h-4 text-[#004b87]" />
            Pedidos dos Irmãos ({filteredPrayers.length})
          </h4>

          {/* Search Box */}
          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar pedidos..."
              className="pl-8 pr-3 py-1.5 bg-[#FAF9F5] border border-[#e5e0d5] focus:border-[#004b87] rounded-xl text-xs text-slate-700 font-sans outline-none max-w-[170px]"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          </div>
        </div>

        {/* Actual prayer lists */}
        {filteredPrayers.length === 0 ? (
          <div className="bg-[#FAF9F5] p-10 rounded-2xl border border-dashed border-[#e5e0d5] text-center text-slate-400 text-xs">
            Nenhum pedido de oração encontrado. Seja o primeiro a publicar um pedido no formulário acima!
          </div>
        ) : (
          <div className="space-y-4 max-h-[500px] overflow-y-auto pr-1">
            {filteredPrayers.map((prayer) => (
              <div
                key={prayer.id}
                className="bg-[#FAF9F5] border border-[#e5e0d5] rounded-2xl p-4 space-y-3.5 shadow-sm hover:border-slate-350 transition-all text-left"
              >
                <div className="flex justify-between items-start gap-2">
                  <div className="space-y-1">
                    <span className="text-xs font-black text-[#0f2646]">{prayer.author}</span>
                    <span className="text-[9px] text-slate-400 font-mono font-bold block">{prayer.date}</span>
                  </div>

                  {prayer.isCustom && (
                    <button
                      onClick={() => handleRemoveOwn(prayer.id)}
                      className="text-slate-400 hover:text-red-500 transition-all p-1 cursor-pointer"
                      title="Remover meu pedido"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                <p className="text-xs md:text-sm text-slate-650 leading-relaxed font-sans break-words bg-white border border-slate-200/40 p-3 rounded-xl font-medium">
                  "{prayer.content}"
                </p>

                <div className="flex justify-between items-center pt-1 border-t border-slate-200/20">
                  <span className="text-[10px] text-slate-500 font-bold font-sans italic flex items-center gap-1">
                    <span>🙏</span> {prayer.prayinCount} {prayer.prayinCount === 1 ? 'irmão está orando' : 'irmãos estão orando'}
                  </span>

                  <button
                    onClick={() => handlePrayReact(prayer.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all cursor-pointer ${
                      prayer.userReacted
                        ? 'bg-[#b48a30]/10 text-[#b48a30] border border-[#b48a30]/30 scale-[1.02]'
                        : 'bg-white hover:bg-slate-50 text-slate-600 border border-[#e5e0d5]'
                    }`}
                  >
                    <span className="text-xs">🙏</span>
                    <span>{prayer.userReacted ? 'Orando! (Retirar)' : 'Orar Junto'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
