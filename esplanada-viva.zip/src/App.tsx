import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Home, 
  BookOpen, 
  HeartHandshake, 
  Award, 
  Compass, 
  History, 
  Bell, 
  User, 
  ShieldAlert, 
  Sparkles, 
  LogOut, 
  Sliders, 
  ChevronRight, 
  ListRestart, 
  X,
  MessageSquare,
  Gift,
  Users
} from 'lucide-react';

// Import Types
import { 
  UserProfileData, 
  SabbathLesson, 
  BibleReading, 
  SpiritualReflection, 
  MissionChallenge, 
  Medal, 
  ActivityHistory, 
  NotificationSettingsData 
} from './types';

// Import Initial Datasets & Helpers
import { 
  LEVEL_STEPS, 
  INITIAL_LESSONS, 
  INITIAL_BIBLE_READINGS, 
  INITIAL_MISSIONS, 
  INITIAL_MEDALS, 
  INITIAL_MILESTONES 
} from './initialData';

// Import Views
import WelcomeScreen from './components/WelcomeScreen';
import AuthScreen from './components/AuthScreen';
import logoImg from './components/logo.png';
import Dashboard from './components/Dashboard';
import TabCommunion from './components/TabCommunion';
import TabMission from './components/TabMission';
import UserProfile from './components/UserProfile';
import GrowthPath from './components/GrowthPath';
import HistoryLogs from './components/HistoryLogs';
import NotificationSettings from './components/NotificationSettings';
import AdminPanel from './components/AdminPanel';
import TabRelationship from './components/TabRelationship';

export default function App() {
  // Navigation & Screen Control state
  const [isOnboarded, setIsOnboarded] = useState<boolean>(false);
  const [user, setUser] = useState<UserProfileData | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'communion' | 'mission' | 'path' | 'relationship' | 'medals' | 'history' | 'notifications' | 'admin'>('dashboard');
  
  // Simulated core DB states
  const [lessons, setLessons] = useState<SabbathLesson[]>(INITIAL_LESSONS);
  const [bibleReadings, setBibleReadings] = useState<BibleReading[]>(INITIAL_BIBLE_READINGS);
  const [reflections, setReflections] = useState<SpiritualReflection[]>([]);
  const [missions, setMissions] = useState<MissionChallenge[]>(INITIAL_MISSIONS);
  const [medals, setMedals] = useState<Medal[]>(INITIAL_MEDALS);
  const [activityLogs, setActivityLogs] = useState<ActivityHistory[]>([]);
  const [notificationConfig, setNotificationConfig] = useState<NotificationSettingsData>({
    remindLesson: true,
    remindStreak: true,
    remindProgression: true,
    lessonTime: '07:30',
  });

  // Daily target completion flags (resets on Simulate New Day)
  const [dailyStatus, setDailyStatus] = useState({
    lessonCompleted: false,
    bibleCompleted: false,
    reflectionCompleted: false,
    missionCompleted: false,
  });

  // Global Mock Roster for Admin panel
  const [mockUserRoster, setMockUserRoster] = useState<UserProfileData[]>([
    {
      id: 'usr-1',
      fullName: 'Larissa Alencar',
      email: 'larissa@alencar.com',
      gender: 'feminino',
      avatarUrl: 'female',
      level: 3,
      xp: 1850,
      xpNeededForNextLevel: 3000,
      totalPoints: 1850,
      streakDays: 8,
      lastAccessDate: '2026-06-18',
      createdAt: '2026-04-12',
      bibleReadingsCount: 15,
      completedMissionsCount: 6,
      reflectionsCount: 8,
      lessonsStudiedCount: 5,
      church: 'Jardim Esplanada'
    },
    {
      id: 'usr-2',
      fullName: 'Tiago Oliveira',
      email: 'tiago@oliveira.net',
      gender: 'masculino',
      avatarUrl: 'male',
      level: 2,
      xp: 750,
      xpNeededForNextLevel: 1500,
      totalPoints: 750,
      streakDays: 4,
      lastAccessDate: '2026-06-17',
      createdAt: '2026-05-20',
      bibleReadingsCount: 6,
      completedMissionsCount: 2,
      reflectionsCount: 3,
      lessonsStudiedCount: 2,
      church: 'Bonsucesso'
    },
    {
      id: 'usr-3',
      fullName: 'Gabriela Mendes',
      email: 'gabi@mendes.com.br',
      gender: 'feminino',
      avatarUrl: 'female',
      level: 4,
      xp: 3450,
      xpNeededForNextLevel: 5000,
      totalPoints: 3450,
      streakDays: 14,
      lastAccessDate: '2026-06-18',
      createdAt: '2026-03-01',
      bibleReadingsCount: 28,
      completedMissionsCount: 12,
      reflectionsCount: 15,
      lessonsStudiedCount: 7,
      church: 'Carambeí Central'
    },
    {
      id: 'usr-4',
      fullName: 'Ricardo Santos',
      email: 'ricardo@santos.net',
      gender: 'masculino',
      avatarUrl: 'male',
      level: 1,
      xp: 320,
      xpNeededForNextLevel: 500,
      totalPoints: 320,
      streakDays: 2,
      lastAccessDate: '2026-06-18',
      createdAt: '2026-06-10',
      bibleReadingsCount: 3,
      completedMissionsCount: 1,
      reflectionsCount: 1,
      lessonsStudiedCount: 1,
      church: 'Jardim Eldorado'
    },
    {
      id: 'usr-5',
      fullName: 'Eunice Santos Souza',
      email: 'eunice@souza.com',
      gender: 'feminino',
      avatarUrl: 'female',
      level: 5,
      xp: 5900,
      xpNeededForNextLevel: 8000,
      totalPoints: 5900,
      streakDays: 32,
      lastAccessDate: '2026-06-18',
      createdAt: '2026-01-15',
      bibleReadingsCount: 45,
      completedMissionsCount: 18,
      reflectionsCount: 22,
      lessonsStudiedCount: 7,
      church: 'Bonsucesso'
    },
    {
      id: 'usr-6',
      fullName: 'Felipe Alencar Araújo',
      email: 'felipe@araujo.org',
      gender: 'masculino',
      avatarUrl: 'male',
      level: 3,
      xp: 2200,
      xpNeededForNextLevel: 3000,
      totalPoints: 2200,
      streakDays: 11,
      lastAccessDate: '2026-06-18',
      createdAt: '2026-04-05',
      bibleReadingsCount: 14,
      completedMissionsCount: 4,
      reflectionsCount: 9,
      lessonsStudiedCount: 4,
      church: 'Jardim Esplanada'
    }
  ]);

  // In-app Notification / Toast Banner State
  const [activeToast, setActiveToast] = useState<string | null>(null);
  
  // Level Up Modal Celebration State
  const [celebrateLevelUp, setCelebrateLevelUp] = useState<{ oldLvl: number; newLvl: number; title: string } | null>(null);

  // 1. Initial State Hydration on Mount
  useEffect(() => {
    try {
      // One-time cleanup for fresh registration testing run on Distrito Esplanada
      if (!localStorage.getItem('discipulado_v3_registration_cleanup')) {
        localStorage.removeItem('discipulado_active_user');
        localStorage.removeItem('discipulado_roster');
        localStorage.removeItem('discipulado_onboarded');
        localStorage.removeItem('discipulado_lessons');
        localStorage.removeItem('discipulado_bible_readings');
        localStorage.removeItem('discipulado_reflections');
        localStorage.removeItem('discipulado_missions');
        localStorage.removeItem('discipulado_medals');
        localStorage.removeItem('discipulado_logs');
        localStorage.removeItem('discipulado_notifs');
        localStorage.removeItem('discipulado_daily_status');
        localStorage.setItem('discipulado_v3_registration_cleanup', 'true');
        
        // Also ensure current in-memory values are reset and return early to load fresh templates
        setUser(null);
        setIsOnboarded(false);
      }

      const storedOnboard = localStorage.getItem('discipulado_onboarded');
      if (storedOnboard) setIsOnboarded(true);

      const storedUser = localStorage.getItem('discipulado_active_user');
      if (storedUser) {
        const parsed = JSON.parse(storedUser);
        setUser(parsed);
      }

      const storedLessons = localStorage.getItem('discipulado_lessons');
      if (storedLessons) {
        try {
          const parsed = JSON.parse(storedLessons);
          if (Array.isArray(parsed) && parsed.length === 7) {
            setLessons(parsed);
          } else {
            setLessons(INITIAL_LESSONS);
            localStorage.setItem('discipulado_lessons', JSON.stringify(INITIAL_LESSONS));
          }
        } catch (e) {
          setLessons(INITIAL_LESSONS);
        }
      }

      const storedBible = localStorage.getItem('discipulado_bible_readings');
      if (storedBible) setBibleReadings(JSON.parse(storedBible));

      const storedReflections = localStorage.getItem('discipulado_reflections');
      if (storedReflections) setReflections(JSON.parse(storedReflections));

      const storedMissions = localStorage.getItem('discipulado_missions');
      if (storedMissions) setMissions(JSON.parse(storedMissions));

      const storedMedals = localStorage.getItem('discipulado_medals');
      if (storedMedals) setMedals(JSON.parse(storedMedals));

      const storedLogs = localStorage.getItem('discipulado_logs');
      if (storedLogs) setActivityLogs(JSON.parse(storedLogs));

      const storedNotifs = localStorage.getItem('discipulado_notifs');
      if (storedNotifs) setNotificationConfig(JSON.parse(storedNotifs));

      const storedDaily = localStorage.getItem('discipulado_daily_status');
      if (storedDaily) setDailyStatus(JSON.parse(storedDaily));

      const storedRoster = localStorage.getItem('discipulado_roster');
      if (storedRoster) setMockUserRoster(JSON.parse(storedRoster));
    } catch (e) {
      console.error("Erro carregando cache LocalStorage", e);
    }
  }, []);

  // 2. Persist states on modification
  const saveToStorage = (key: string, value: any) => {
    localStorage.setItem(key, JSON.stringify(value));
  };

  // Trigger temporary floating Toast
  const triggerToast = (text: string) => {
    setActiveToast(text);
    // Dismiss automatically
    const timer = setTimeout(() => {
      setActiveToast(null);
    }, 5000);
    return () => clearTimeout(timer);
  };

  // Helper dynamic Level Up Calculator
  const checkLevelUp = (totalXp: number, oldLevel: number) => {
    let nextLvl = 1;
    let title = 'Novo na Jornada';
    let nextThreshold = 500;

    for (const step of LEVEL_STEPS) {
      if (totalXp >= step.minXp) {
        nextLvl = step.level;
        title = step.title;
        const nextStep = LEVEL_STEPS.find(s => s.level === step.level + 1);
        nextThreshold = nextStep ? nextStep.minXp : 12000;
      }
    }

    return { level: nextLvl, title, nextThreshold };
  };

  // CORE REWARD FUNCTION: Updates User details, logs activity, checks Level Up and evaluates Medals
  const handleAwardXp = (
    xpAmount: number, 
    activityType: ActivityHistory['type'], 
    title: string, 
    observation?: string
  ) => {
    if (!user) return;

    setUser((prevUser) => {
      if (!prevUser) return null;

      // 1. Calculate new points & XP
      const updatedTotalPoints = prevUser.totalPoints + xpAmount;
      const updatedXp = prevUser.xp + xpAmount;
      
      // 2. Compute Level Up limits
      const { level: computedLevel, title: levelTitle, nextThreshold } = checkLevelUp(updatedTotalPoints, prevUser.level);

      // Check if they moved to a higher level
      if (computedLevel > prevUser.level) {
        setCelebrateLevelUp({
          oldLvl: prevUser.level,
          newLvl: computedLevel,
          title: levelTitle
        });

        // Push bonus log for Level Up
        appendActivityLog('nível_up', `Parabéns! Subiu de Nível para ${computedLevel} - ${levelTitle}!`, 50);
        triggerToast(`🎉 Subiu de Nível! Você agora é um ${levelTitle}!`);
      }

      // Update dynamic diagnostic counts
      let updatedBibleReadingsCount = prevUser.bibleReadingsCount;
      let updatedCompletedMissionsCount = prevUser.completedMissionsCount;
      let updatedReflectionsCount = prevUser.reflectionsCount;
      let updatedLessonsStudiedCount = prevUser.lessonsStudiedCount;

      if (activityType === 'bíblia') updatedBibleReadingsCount += 1;
      if (activityType === 'missão') updatedCompletedMissionsCount += 1;
      if (activityType === 'reflexão') updatedReflectionsCount += 1;
      if (activityType === 'lição') updatedLessonsStudiedCount += 1;

      const newUserState: UserProfileData = {
        ...prevUser,
        totalPoints: updatedTotalPoints,
        xp: updatedXp,
        level: computedLevel,
        xpNeededForNextLevel: nextThreshold,
        bibleReadingsCount: updatedBibleReadingsCount,
        completedMissionsCount: updatedCompletedMissionsCount,
        reflectionsCount: updatedReflectionsCount,
        lessonsStudiedCount: updatedLessonsStudiedCount
      };

      // Auto-examine and unlock medals roster based on current stats
      checkMedalUnlocks(newUserState);

      saveToStorage('discipulado_active_user', newUserState);
      return newUserState;
    });

    // Append to chronological history
    appendActivityLog(activityType, title, xpAmount, observation);
  };

  const appendActivityLog = (
    type: ActivityHistory['type'], 
    title: string, 
    xp: number, 
    obs?: string
  ) => {
    const newLog: ActivityHistory = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      date: new Date().toISOString().replace('T', ' ').substring(0, 16),
      type,
      title,
      xpReceived: xp,
      observation: obs
    };

    setActivityLogs((prev) => {
      const updated = [newLog, ...prev];
      saveToStorage('discipulado_logs', updated);
      return updated;
    });
  };

  // Scans requirements to unlock medals
  const checkMedalUnlocks = (currentUserState: UserProfileData) => {
    setMedals((prevMedals) => {
      let changed = false;
      const updated = prevMedals.map((medal) => {
        if (medal.unlockedAt) return medal; // Already unlocked

        let satisfies = false;
        if (medal.conditionType === 'streak' && currentUserState.streakDays >= medal.conditionValue) satisfies = true;
        if (medal.conditionType === 'lessons' && currentUserState.lessonsStudiedCount >= medal.conditionValue) satisfies = true;
        if (medal.conditionType === 'reflections' && currentUserState.reflectionsCount >= medal.conditionValue) satisfies = true;
        if (medal.conditionType === 'missions' && currentUserState.completedMissionsCount >= medal.conditionValue) satisfies = true;
        if (medal.conditionType === 'readings') {
          // If 100 base is perfect Bible progress
          if (medal.conditionValue === 100) {
            const currentPercent = Math.round((currentUserState.bibleReadingsCount / bibleReadings.length) * 100);
            if (currentPercent >= 100) satisfies = true;
          } else if (currentUserState.bibleReadingsCount >= medal.conditionValue) {
            satisfies = true;
          }
        }

        if (satisfies) {
          changed = true;
          triggerToast(`🏆 Nova conquista desbloqueada: ${medal.name}!`);
          return {
            ...medal,
            unlockedAt: new Date().toLocaleDateString('pt-BR')
          };
        }
        return medal;
      });

      if (changed) {
        saveToStorage('discipulado_medals', updated);
      }
      return updated;
    });
  };

  // 3. ACTIONS HANDLERS FROM DOCK OR SUB-PAGES
  const handleOnboardingComplete = () => {
    setIsOnboarded(true);
    localStorage.setItem('discipulado_onboarded', 'true');
  };

  const handleAuthSuccess = (loggedUser: UserProfileData) => {
    setUser(loggedUser);
    saveToStorage('discipulado_active_user', loggedUser);
    
    // Add first access log if empty
    setActivityLogs((prev) => {
      if (prev.length === 0) {
        const joinLog: ActivityHistory = {
          id: `log-joined`,
          date: new Date().toISOString().replace('T', ' ').substring(0, 16),
          type: 'streak_bônus',
          title: 'Ingressou na Aliança Espiritual',
          xpReceived: loggedUser.xp,
          observation: 'Inicio da caminhada de discipulado diário.'
        };
        const init = [joinLog];
        saveToStorage('discipulado_logs', init);
        return init;
      }
      return prev;
    });

    // Include user in administrators roster list if they are not already there
    setMockUserRoster((prev) => {
      if (!prev.some(u => u.email === loggedUser.email)) {
        const updated = [loggedUser, ...prev];
        saveToStorage('discipulado_roster', updated);
        return updated;
      }
      return prev;
    });

    triggerToast(`Olá, ${loggedUser.fullName}! Bons estudos espirituais hoje.`);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('discipulado_active_user');
    setActiveTab('dashboard');
    triggerToast('Desconectado com sucesso.');
  };

  // Handle communion actions
  const handleCompleteLesson = (lessonId: string, answer: string) => {
    setLessons((prev) => {
      const updated = prev.map((l) => l.id === lessonId ? { ...l, completed: true, answer } : l);
      saveToStorage('discipulado_lessons', updated);
      return updated;
    });

    setDailyStatus((prev) => {
      const s = { ...prev, lessonCompleted: true };
      saveToStorage('discipulado_daily_status', s);
      return s;
    });

    // Award standard points
    handleAwardXp(10, 'lição', 'Estudo de Lição Sabatina', 'Marcar estudo como lido.');
    handleAwardXp(15, 'reflexão', 'Anotação de Aprendizado', `Resposta: "${answer.slice(0, 50)}..."`);
  };

  const handleCompleteBibleReading = (readingId: string) => {
    setBibleReadings((prev) => {
      const updated = prev.map((r) => r.id === readingId ? { ...r, completed: true } : r);
      saveToStorage('discipulado_bible_readings', updated);
      return updated;
    });

    setDailyStatus((prev) => {
      const s = { ...prev, bibleCompleted: true };
      saveToStorage('discipulado_daily_status', s);
      return s;
    });

    const passage = bibleReadings.find(r => r.id === readingId)?.passage || 'Passagem da Bíblia';
    handleAwardXp(10, 'bíblia', `Leitura Bíblica: ${passage}`);
  };

  const handleSaveReflection = (content: string, type: 'oração' | 'aprendizado' | 'gratidão' | 'reflexão') => {
    const newRef: SpiritualReflection = {
      id: `ref-${Date.now()}`,
      date: new Date().toLocaleDateString('pt-BR'),
      content,
      type
    };

    setReflections((prev) => {
      const updated = [newRef, ...prev];
      saveToStorage('discipulado_reflections', updated);
      return updated;
    });

    setDailyStatus((prev) => {
      const s = { ...prev, reflectionCompleted: true };
      saveToStorage('discipulado_daily_status', s);
      return s;
    });

    handleAwardXp(15, 'reflexão', `Reflexão do Diário: ${type.toUpperCase()}`, content);
  };

  const handleDeleteReflection = (id: string) => {
    setReflections((prev) => {
      const updated = prev.filter(r => r.id !== id);
      saveToStorage('discipulado_reflections', updated);
      return updated;
    });
    triggerToast('Reflexão removida do diário.');
  };

  // Handle mission completion
  const handleCompleteMission = (missionId: string, notes: string) => {
    const targetMission = missions.find(m => m.id === missionId);
    if (!targetMission) return;

    setMissions((prev) => {
      const updated = prev.map((m) => m.id === missionId ? { ...m, completedCount: m.completedCount + 1 } : m);
      saveToStorage('discipulado_missions', updated);
      return updated;
    });

    setDailyStatus((prev) => {
      const s = { ...prev, missionCompleted: true };
      saveToStorage('discipulado_daily_status', s);
      return s;
    });

    handleAwardXp(
      targetMission.xpReward, 
      'missão', 
      `Ação Missionária: ${targetMission.title}`, 
      notes || 'Concluído sem observações'
    );
  };

  // Administration interactions
  const handleCreateMissionAdmin = (newMission: Omit<MissionChallenge, 'completedCount'>) => {
    const payload: MissionChallenge = {
      ...newMission,
      completedCount: 0
    };
    setMissions((prev) => {
      const updated = [...prev, payload];
      saveToStorage('discipulado_missions', updated);
      return updated;
    });
    triggerToast(`Desafio "${payload.title}" criado com sucesso.`);
  };

  const handleUpdateMissionAdmin = (updated: MissionChallenge) => {
    setMissions((prev) => {
      const u = prev.map((m) => m.id === updated.id ? updated : m);
      saveToStorage('discipulado_missions', u);
      return u;
    });
    triggerToast(`Desafio editado.`);
  };

  const handleModifyUserXpAdmin = (userId: string, xpChange: number) => {
    // Update active user if they are the admin editing themselves
    if (user && user.id === userId) {
      handleAwardXp(xpChange, 'streak_bônus', 'Ajuste manual pela administração', 'Alterado pelo God mode');
      return;
    }

    setMockUserRoster((prev) => {
      const updated = prev.map((u) => {
        if (u.id === userId) {
          const newTotalPoints = Math.max(u.totalPoints + xpChange, 0);
          const { level: computedLevel, title: levelTitle, nextThreshold } = checkLevelUp(newTotalPoints, u.level);
          return {
            ...u,
            totalPoints: newTotalPoints,
            xp: newTotalPoints,
            level: computedLevel,
            xpNeededForNextLevel: nextThreshold
          };
        }
        return u;
      });
      saveToStorage('discipulado_roster', updated);
      return updated;
    });
    triggerToast(`XP de usuário alterado para fins de validação.`);
  };

  const handleToggleUserAdminRole = (userId: string, newRole: 'admin' | 'user') => {
    // If updating current user
    if (user && user.id === userId) {
      const updatedUser = { ...user, role: newRole };
      setUser(updatedUser);
      saveToStorage('discipulado_active_user', updatedUser);
    }
    
    setMockUserRoster((prev) => {
      const updated = prev.map((u) => {
        if (u.id === userId) {
          return { ...u, role: newRole };
        }
        return u;
      });
      saveToStorage('discipulado_roster', updated);
      return updated;
    });
    
    // Trigger toast notifying role change
    const searchList = user ? [user, ...mockUserRoster] : mockUserRoster;
    const userName = searchList.find(u => u.id === userId)?.fullName || 'Membro';
    const roleTxt = newRole === 'admin' ? 'definido como Administrador' : 'removido do cargo de Administrador';
    triggerToast(`${userName} foi ${roleTxt}.`);
  };

  const handleSaveNotifications = (updated: NotificationSettingsData) => {
    setNotificationConfig(updated);
    saveToStorage('discipulado_notifs', updated);
  };

  // SIMULATOR TRIGGER: "Avançar Próximo Dia"
  // Let the user emulate progress on streaks without waiting 24 physical hours!
  const handleSimulateNewDay = () => {
    // Determine streak behavior (has completed at least one activity?)
    const didAnything = dailyStatus.lessonCompleted || dailyStatus.bibleCompleted || dailyStatus.reflectionCompleted || dailyStatus.missionCompleted;
    
    setUser((prevUser) => {
      if (!prevUser) return null;
      
      let nextStreak = prevUser.streakDays;
      if (didAnything) {
        nextStreak += 1;
        triggerToast(`🔥 Ótimo! Sequência de dias mantida! Você agora está em ${nextStreak} dias consecutivos.`);
        // Bonus points for keeping status
        setTimeout(() => {
          handleAwardXp(5, 'streak_bônus', `Bônus Diário de Sequência (${nextStreak} dias)`, `Streak ativado!`);
        }, 1000);
      } else {
        nextStreak = 1; // broken counter
        triggerToast('⚠️ Nenhuma atividade foi feita hoje. Sua sequência foi resetada para 1 dia.');
      }

      const updated: UserProfileData = {
        ...prevUser,
        streakDays: nextStreak,
        lastAccessDate: new Date().toISOString().split('T')[0]
      };
      
      saveToStorage('discipulado_active_user', updated);
      return updated;
    });

    // Reset daily status
    const resetDaily = {
      lessonCompleted: false,
      bibleCompleted: false,
      reflectionCompleted: false,
      missionCompleted: false,
    };
    setDailyStatus(resetDaily);
    saveToStorage('discipulado_daily_status', resetDaily);
  };

  // Helper calculation for overall Bible progress
  const bibleCompletedCount = bibleReadings.filter(r => r.completed).length;
  const biblePercent = bibleReadings.length > 0 
    ? Math.round((bibleCompletedCount / bibleReadings.length) * 100) 
    : 0;

  // Render core views
  const renderTabContent = () => {
    if (!user) return null;

    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard
            user={user}
            dailyStatus={dailyStatus}
            onQuickAction={(action) => {
              if (action === 'licao') setActiveTab('communion');
              if (action === 'bible') { setActiveTab('communion'); }
              if (action === 'reflection') setActiveTab('communion');
              if (action === 'mission') setActiveTab('mission');
              if (action === 'path') setActiveTab('path');
              if (action === 'medals') setActiveTab('medals');
              if (action === 'admin') setActiveTab('admin');
            }}
            isAdminUser={isAdminUser}
          />
        );
      case 'communion':
        return (
          <TabCommunion
            lessons={lessons}
            bibleReadings={bibleReadings}
            reflections={reflections}
            bibleProgressPercent={biblePercent}
            onCompleteLesson={handleCompleteLesson}
            onCompleteBibleReading={handleCompleteBibleReading}
            onSaveReflection={handleSaveReflection}
            onDeleteReflection={handleDeleteReflection}
          />
        );
      case 'mission':
        return (
          <TabMission
            missions={missions}
            userLevel={user.level}
            onCompleteMission={handleCompleteMission}
          />
        );
      case 'path':
        return <GrowthPath user={user} />;
      case 'relationship':
        return <TabRelationship />;
      case 'medals':
        return (
          <UserProfile
            user={user}
            medals={medals}
            bibleProgressPercent={biblePercent}
            totalActivitiesCount={activityLogs.length}
            onUpdateUserProfile={(newUser) => {
              setUser(newUser);
              saveToStorage('discipulado_active_user', newUser);
            }}
          />
        );
      case 'history':
        return <HistoryLogs logs={activityLogs} />;
      case 'notifications':
        return (
          <NotificationSettings
            initialConfig={notificationConfig}
            onSaveConfig={handleSaveNotifications}
            triggerMockNotification={(txt) => triggerToast(txt)}
          />
        );
      case 'admin':
        return (
          <AdminPanel
            challenges={missions}
            userList={[user, ...mockUserRoster]}
            totalActivitiesCount={activityLogs.length}
            onCreateMission={handleCreateMissionAdmin}
            onUpdateMission={handleUpdateMissionAdmin}
            onModifyUserXp={handleModifyUserXpAdmin}
            onToggleUserAdminRole={handleToggleUserAdminRole}
          />
        );
      default:
        return <Dashboard user={user} dailyStatus={dailyStatus} onQuickAction={() => {}} />;
    }
  };

  // If not onboarded, display onboarding steps
  if (!isOnboarded) {
    return <WelcomeScreen onComplete={handleOnboardingComplete} />;
  }

  // If onboarded but not authenticated
  if (!user) {
    return <AuthScreen onAuthSuccess={handleAuthSuccess} />;
  }

  const isAdminUser = user.email === 'admin@discipulado.com' || user.id === 'admin-user-id' || user.role === 'admin';

  return (
    <div className="min-h-screen bg-[#FAF9F5] text-slate-800 font-sans flex flex-col justify-between relative transition-colors duration-400">
      
      {/* Dynamic Floating Toast Alerts */}
      <AnimatePresence>
        {activeToast && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -50, scale: 0.95 }}
            className="fixed top-4 left-1/2 -translate-x-1/2 w-11/12 max-w-sm bg-white border-2 border-[#004b87] rounded-2xl p-4 z-50 shadow-2xl flex items-start gap-3"
          >
            <div className="bg-[#004b87] p-1.5 rounded-lg text-white mt-0.5 shrink-0">
              <Sparkles className="w-4 h-4 fill-white" />
            </div>
            <div className="text-left flex-1 min-w-0">
              <span className="text-[9px] uppercase tracking-wider font-extrabold text-[#004b87] block">Aviso do Templo</span>
              <p className="text-xs text-slate-700 mt-1 leading-normal break-words">
                {activeToast}
              </p>
            </div>
            <button 
              onClick={() => setActiveToast(null)} 
              className="text-slate-400 hover:text-slate-600 p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Level Up Celebration Celebration Modal */}
      <AnimatePresence>
        {celebrateLevelUp && (
          <div className="fixed inset-0 bg-[#0f2646]/80 backdrop-blur-md flex items-center justify-center p-6 z-50">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white border-2 border-[#b48a30] rounded-3xl p-6 text-center max-w-sm w-full space-y-5 shadow-2xl"
            >
              <span className="text-[10px] font-black tracking-widest text-[#b48a30] uppercase block">Crescimento Espiritual</span>
              
              <div className="relative mx-auto w-24 h-24 bg-amber-50 rounded-full flex items-center justify-center border border-[#b48a30]/20">
                <Sparkles className="w-12 h-12 text-[#b48a30] animate-pulse" />
              </div>

              <div className="space-y-1.5">
                <h3 className="text-2xl font-black text-[#0f2646]">SUBIU DE NÍVEL!</h3>
                <p className="text-xs text-slate-600">
                  Sua constância e devoção renderam amadurecimento visível. Você agora é considerado:
                </p>
                <span className="inline-block text-[#b48a30] font-black tracking-wide text-lg bg-[#FAF9F5] px-4 py-1.5 rounded-full border border-[#b48a30]/30">
                  Nível {celebrateLevelUp.newLvl} - {celebrateLevelUp.title}
                </span>
              </div>

              <p className="text-[11px] text-slate-500 italic pb-2">
                "Antes crescei na graça e conhecimento de nosso Senhor..."
              </p>

              <button
                id="btn-level-congratulations-close"
                onClick={() => setCelebrateLevelUp(null)}
                className="w-full bg-[#004b87] hover:bg-[#003763] text-white font-bold py-3 rounded-xl transition-all font-sans text-xs cursor-pointer shadow-md"
              >
                Glorificar e Avançar
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Desktop Wrapper Mimics Premium Smartphone Chassis Centered */}
      <div className="w-full max-w-lg mx-auto bg-[#F5F3EC] min-h-screen flex flex-col justify-between border-x border-[#cbd5e1] shadow-2xl relative">
        
        {/* Dynamic App Shell Header */}
        <header className="bg-[#0f2646] text-white border-b border-[#0a1a30] p-4 sticky top-0 z-40 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center shrink-0">
              <img src={logoImg} alt="SDA Logo" referrerPolicy="no-referrer" className="h-16 w-auto max-w-[160px] object-contain" />
            </div>
            <div className="text-left leading-none">
              <span id="app-brand" className="font-extrabold text-sm tracking-wide text-white">Esplanada Viva</span>
              <span className="text-[8px] text-[#b48a30] block font-black tracking-widest uppercase mt-1">DISTRITO ESPLANADA</span>
            </div>
          </div>

          {/* Upper actions */}
          <div className="flex items-center gap-1.5">
            {/* Simulate Next Day Trigger (Ultimate Evaluator Helper) */}
            <button
              id="sidebar-btn-simulate-day"
              onClick={handleSimulateNewDay}
              className="bg-[#0a1a30] hover:bg-[#112744] text-slate-300 p-2 rounded-xl transition-all border border-[#1a2d44] group relative cursor-pointer"
              title="Avançar Próximo Dia (Simulação de Streak)"
            >
              <ListRestart className="w-4 h-4" />
              <span className="hidden sm:inline text-[9px] font-bold uppercase ml-1.5 font-mono">Simular Dia</span>
            </button>

            {/* Quick Admin shortcut if logged/flag is true */}
            {isAdminUser && (
              <button
                id="header-btn-admin"
                onClick={() => setActiveTab(activeTab === 'admin' ? 'dashboard' : 'admin')}
                className={`p-2 rounded-xl transition-all border cursor-pointer ${
                  activeTab === 'admin'
                    ? 'bg-rose-500/15 text-rose-300 border-rose-500/30'
                    : 'bg-[#0a1a30] text-slate-350 border-[#1a2d44] hover:text-rose-400'
                }`}
                title="Ir p/ Painel de Admin"
              >
                <ShieldAlert className="w-4 h-4" />
              </button>
            )}

            {/* Log out */}
            <button
              id="header-btn-logout"
              onClick={handleLogout}
              className="p-2 rounded-xl bg-[#0a1a30] text-slate-350 hover:text-white border border-[#1a2d44] transition-all font-sans cursor-pointer"
              title="Sair do Perfil"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Dynamic Screen Content Wrapper Container */}
        <main className="flex-1 overflow-y-auto p-4 md:p-5 relative">
          
          {renderTabContent()}
        </main>

        {/* Global Bottom Navigation Tab Bar */}
        <nav className="bg-white border-t border-[#e5e0d5] py-2.5 px-1.5 flex items-center justify-around sticky bottom-0 z-40 rounded-t-2xl shadow-xl w-full max-w-full overflow-hidden">
          <button
            id="nav-btn-home"
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 sm:px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'dashboard' ? 'text-[#004b87] font-extrabold scale-105' : 'text-slate-400 hover:text-[#004b87]'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[9px] font-extrabold font-mono">Início</span>
          </button>

          <button
            id="nav-btn-communion"
            onClick={() => setActiveTab('communion')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 sm:px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'communion' ? 'text-[#004b87] font-extrabold scale-105' : 'text-slate-400 hover:text-[#004b87]'
            }`}
          >
            <BookOpen className="w-5 h-5" />
            <span className="text-[9px] font-extrabold font-mono">Comunhão</span>
          </button>

          <button
            id="nav-btn-mission"
            onClick={() => setActiveTab('mission')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 sm:px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'mission' ? 'text-[#004b87] font-extrabold scale-105' : 'text-slate-400 hover:text-[#004b87]'
            }`}
          >
            <HeartHandshake className="w-5 h-5" />
            <span className="text-[9px] font-extrabold font-mono">Missão</span>
          </button>

          <button
            id="nav-btn-path"
            onClick={() => setActiveTab('path')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 sm:px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'path' ? 'text-[#004b87] font-extrabold scale-105' : 'text-slate-400 hover:text-[#004b87]'
            }`}
          >
            <Compass className="w-5 h-5" />
            <span className="text-[9px] font-extrabold font-mono">Trilha</span>
          </button>

          <button
            id="nav-btn-relationship"
            onClick={() => setActiveTab('relationship')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 sm:px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'relationship' ? 'text-[#004b87] font-extrabold scale-105' : 'text-slate-400 hover:text-[#004b87]'
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="text-[9px] font-extrabold font-mono">Oração</span>
          </button>

          <button
            id="nav-btn-medals"
            onClick={() => setActiveTab('medals')}
            className={`flex flex-col items-center gap-1 py-1 px-1.5 sm:px-3 rounded-xl transition-all cursor-pointer ${
              activeTab === 'medals' ? 'text-[#004b87] font-extrabold scale-105' : 'text-slate-400 hover:text-[#004b87]'
            }`}
          >
            <Award className="w-5 h-5" />
            <span className="text-[9px] font-extrabold font-mono">Perfil</span>
          </button>
        </nav>
      </div>
    </div>
  );
}
